# Hnuter 两级倾转臂完整系统辨识

程序直接发布 PX4 `ActuatorMotors`、`ActuatorServos` 和 `OffboardControlMode`。完整测试对一级、二级分别执行多角度正负阶跃和对数正弦扫频，另一轴始终保持中立。

默认测试序列：

- 实际目标角 `±3°、±5°、±10°、±15°、±30°、±45°、±60°、±75°、±90°`，每个方向重复 3 次。
- 每次阶跃保持 4 秒，中立等待 2 秒。
- 每轴执行一次 `±5°、0.05–2 Hz、60 s` 对数 chirp。
- 100 Hz 持续发布 Offboard heartbeat、电机指令和舵机指令。
- 电机 0–4 默认归一化指令均为 `0.0`。
- 在线实际角速度保护为 `1200°/s`（30° 回中实测瞬时值约 `856°/s`）。
- 完成或异常时回中、Disarm，并切回 Manual。

当前实际角度换算使用 `20260717_192023_step` 的正负方向测量增益，因此 YAML 中的目标角是动捕实际角度目标，不是简单的舵机等效角。完整结果仍以本次动捕实测角度为准。

## 持续 Offboard 的实现方式

实现参考仓库中的 `hnuter_external_direct_controller_debug.py`：

1. 先连续预发布 heartbeat 和中立 direct-actuator setpoint。
2. 请求一次 Offboard，确认进入后再请求 Arm。
3. 测试期间每个控制周期继续发布 `direct_actuator=True`、电机和舵机 setpoint。
4. 不通过循环发送 Arm 命令“保持解锁”；如果 PX4 自动 Disarm，测试立即终止。

与参考控制器一致，程序默认设置 `ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST`，避免局域网中第二个 PX4 使用相同 `/fmu/...` 话题造成状态和执行器命令混流。只有明确设置 `HNUTER_ALLOW_REMOTE_DDS=1` 才允许远程 DDS discovery。

该方式可以保持 Offboard，但不能绕过 PX4 的地面预起飞自动上锁。当前扩展到 90° 的完整默认序列约 776 秒，而 `COM_DISARM_PRFLT` 默认约 10 秒。台架长时间测试前，需要在 QGroundControl 中记录原值并手动将 `COM_DISARM_PRFLT` 设为固件支持的禁用值（通常为 `-1`）；测试结束立即恢复原值。程序不会自动修改任何 PX4 参数。

## 环境与通信检查

```bash
source ~/hnuter_ctrl/bin/activate
source /opt/ros/jazzy/setup.bash
source ~/hnuter_ctrl/install/setup.bash

cd ~/hnuter_ctrl/Hnuter-Controller
```

确认 DDS 和动捕话题：

```bash
ros2 topic list --no-daemon | grep -E 'fmu|mocap|vrpn|pose|transform'

python3 hnuter_tilt_system_id.py --check \
  --body-topic /vrpn_mocap/hnuter/pose \
  --tilt1-topic /vrpn_mocap/tilt1/pose \
  --tilt2-topic /vrpn_mocap/tilt2/pose
```

`--check` 只读取 DDS 和动捕，不发布 PX4 输入。

## 测试命令

短时间方向检查：

```bash
python3 hnuter_tilt_system_id.py --run \
  --test-type mapping_check --neutral 0.4
```

完整多角度阶跃：

```bash
python3 hnuter_tilt_system_id.py --run --test-type step \
  --step-amplitudes 3 5 10 15 30 45 60 75 90 --step-hold 4 --neutral 2 --repeats 3
```

连续正弦扫频：

```bash
python3 hnuter_tilt_system_id.py --run --test-type chirp \
  --chirp-amplitude 5 --chirp-start 0.05 --chirp-end 2 --chirp-duration 60
```

固定频率正弦：

```bash
python3 hnuter_tilt_system_id.py --run --test-type sine \
  --sine-amplitude 5 --sine-frequency 0.5 --sine-duration 20
```

全部测试：

```bash
python3 hnuter_tilt_system_id.py --run --test-type all
```

默认话题已经写入 YAML；也可以在任何命令后显式添加：

```bash
--body-topic /vrpn_mocap/hnuter/pose \
--tilt1-topic /vrpn_mocap/tilt1/pose \
--tilt2-topic /vrpn_mocap/tilt2/pose
```

若不允许临时禁用 `COM_DISARM_PRFLT`，只能运行能在自动上锁前完成的短测试。把长扫频拆成多次 Arm 会破坏 `0.05 Hz` 连续输入，不能得到可靠的低频响应。

## 数据与分析

每次运行创建：

```text
tilt_system_id_data/YYYYmmdd_HHMMSS_<type>/data.csv
```

离线分析：

```bash
python3 hnuter_tilt_system_id_analyze.py \
  tilt_system_id_data/YYYYmmdd_HHMMSS_all/data.csv
```

分析目录包含：

- `report.md`：正负方向最大速度、平均速度、时间常数、纯延迟、增益和超调量。
- `step_events.csv`：每个角度、每次正负阶跃的单独结果。
- `processed_data.csv`：原始列以及自动铰链轴角度、滤波角度和计算角速度。
- `tilt1/tilt2_response.png/pdf`：完整命令、角度和角速度。
- `tilt1/tilt2_chirp.png/pdf`：扫频实测和一阶惯性加纯延迟模型对比。
- `tilt1/tilt2_bode.png/pdf`：幅频、相频和 coherence。

分析使用模型：

```text
G(s) = K * exp(-L*s) / (tau*s + 1)
```

`Ctrl+C`、PX4 状态超时、Offboard/Arm 丢失、实际角度或角速度超过 YAML 限制都会终止测试并发送中立/Disarm/Manual。测试中动捕年龄超过 0.5 秒会立即回中并暂停当前段；3 秒内恢复则从该段开头重测，超过 3 秒才终止整个测试。

CSV 同时记录 `body_mocap_age_s`、`tilt1_mocap_age_s` 和 `tilt2_mocap_age_s`，用于定位大角度下具体哪个刚体发生遮挡或降频。
